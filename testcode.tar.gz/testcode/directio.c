#define _GNU_SOURCE

#include <fcntl.h> // open 
#include <unistd.h> // unlink
#include <string.h> 
#include <stdio.h> // printf
#include <stdlib.h> // atoi
#include <stdlib.h> // atoi
#include <errno.h>
#include <malloc.h> // memalign 
#include <time.h> // rand
#include <sys/types.h> // fsetxattr
#include <sys/time.h> // gettimeofday
#include <sys/stat.h> // open

#define BLK_SIZE 512

double perf_time_diff(struct timeval start, struct timeval end) {
	double time = (end.tv_sec - start.tv_sec) + ((end.tv_usec - start.tv_usec) / (double)1000000);
	return time;
}

int main(int argc, char** argv)
{

  char fname[20] = "Direct"; // 

  // offset, length, alignment should be a multiple of block size (512B) 
  ssize_t num;
  size_t length, alignment;
  off_t offset;
  char* buff;
  int ops, op_size;
  int count;
  ssize_t max_fbytes = 1 << 30;

  // time measurement 
  struct timeval start;
  struct timeval end;
  double Dtime;
  double Rtime;

  length = BLK_SIZE * 8; //ÆÄÀÏÅ©±â
  alignment = BLK_SIZE;
  offset = 0;

  // file open 
  if (argc < 3){
    printf("Usage: ./a.out op_size ops\n");
    printf("e.g.: ./a.out 4096 1000\n");
    return 0;
  }

  op_size = atoi(argv[1])*alignment*2; // atoi = ¹®ÀÚ¿­À» Á€Œö·Î º¯È¯
  ops = atoi(argv[2]);

  printf("op_size = %d, ops = %d\n", op_size, ops);
  length = op_size; // ÀÔ·Â¹ÞÀº °ªÀž·Î length ÁöÁ€

////////////////// write ////////////////////
  int fd, oflag;

  oflag = O_CREAT | O_RDWR | O_DIRECT | O_DSYNC; // direct

  // io
  buff = memalign(alignment * 2, length + alignment); // memalignÀÏÁ€ »çÀÌÁîžžÅ­ÀÇ ºí·Ï ÇÒŽç

  if(buff == NULL){
    printf("Failed to memalign\n");
    goto out;
  } 

  buff += alignment; // buffÀÇ œÃÀÛÁ¡ÀÌ ŽÞ¶óÁü?
  memset(buff, 'a', length); // žÞžðž®¿¡ °ª ÇÒŽç
  //memcpy(buff, "This is my direct file", 200);

  srand((unsigned)time(NULL));

  count = 0; 
  //// Direct start ////

  while(count < ops){ // opsžžÅ­ ¹Ýº¹
	int alignment = 4096; //??
	offset = (rand() % (max_fbytes / alignment)) * alignment;

	gettimeofday(&start, NULL); 

	fd = open(fname, oflag, S_IRUSR | S_IWUSR); // Dflag·Î open.
	if (fd == -1) {
		printf("Failed to open file %s\n", fname);
		return -1;
	}

	/*if (lseek(Dfd, offset, SEEK_SET) == -1){ // ÆÄÀÏ Æ÷ÀÎÅÍžŠ žÇ ŸÕÀž·Î Á¶Á€
		// ÀÌ ŸÆŽÏ¶ó ¿ÀÆÛ·¹ÀÌŒÇ °¹ŒöžžÅ­ œÇÇà žÞžðž®¿¡ œ×°Ô žžµë ¿Ö?
		printf("Failed to lseek\n");
		goto out;//
	}*/

	num = write(fd, buff, length); // ÆÄÀÏ Ÿ²±â
	if (num == -1){
	    printf("Failed to write\n");
		goto out;
	}
	close(fd); 

	gettimeofday(&end, NULL);
	Dtime = perf_time_diff(start, end);   
	
	printf("%lf\n",Dtime);
	count++;
  }
  //// end ////
  
  printf("\n\n\n");

  count = 0;
  ////////////////// read ////////////////////	
  while (count < ops) { // opsžžÅ­ ¹Ýº¹
	  int alignment = 4096; //??
	  offset = (rand() % (max_fbytes / alignment)) * alignment; 	

	  gettimeofday(&start, NULL);

	  fd = open(fname, oflag, S_IRUSR | S_IWUSR); // Dflag·Î open.
	  if (fd == -1) {
		  printf("Failed to open file %s\n", fname);
		  return -1;
	  }

	  /*if (lseek(Bfd, offset, SEEK_SET) == -1) { // ÆÄÀÏ Æ÷ÀÎÅÍžŠ žÇ ŸÕÀž·Î Á¶Á€
		  // ÀÌ ŸÆŽÏ¶ó ¿ÀÆÛ·¹ÀÌŒÇ °¹ŒöžžÅ­ œÇÇà žÞžðž®¿¡ œ×°Ô žžµë ¿Ö?
		  printf("Failed to lseek\n");
		  goto out;//
	  }*/

	  num = read(fd, buff, length); // ÆÄÀÏ ÀÐ±â
	  if (num == -1) {
		  printf("Failed to read\n");
		  goto out;
	  }
	  close(fd);
	  gettimeofday(&end, NULL);

	  Rtime = perf_time_diff(start, end);
	  printf("%lf\n", Rtime);
	  count++;
  }

out:
//  if(buff != NULL)
//    free(buff);
  
  return 0;
}

// direct, bufferd write ÇÏ°í (ŽÙž¥ ÆÄÀÏ·Î Ÿ²ÀÌŽÂÁö È®ÀÎ)
// ¿©·¯¹ø time ÀçŒ­ Æò±Õ°ªÀž·Î ºž¿©ÁÖ°í
// readŽÂ buffered žž ÇÏ°í (ŸŽ ÆÄÀÏ¿¡Œ­ Àß read ÇÏŽÂÁö)
// ÆÄÀÏ Å©±âº°·Î ÃøÁ€ÇØŒ­ read write ŒÓµµžŠ ±×·¡ÇÁ·Î ±×ž°ŽÙ.

